#include <stdio.h>
#include <stdlib.h>
#define N 1000
#define ROOT_RANK 0

int *create_random_int_array(int len){
  int i;
  int *ret;
  ret = (int *)malloc(sizeof(int)*len);
  srand(1);
  for (i=0; i<len; i++)
	  ret[i] = rand() % 10;     
  return ret;
} 

int main(int argc, char **argv){
  const int TAG = 1;
  int  numprocs, rank, i;
  MPI_Status status;
  int *array, length_per_process, pid, count = 0, other_count;



  
  if (rank == ROOT_RANK){
    array = create_random_int_array(N);
	//Display array before counting

    


    
	  }
  else{
    array = (int *) malloc(sizeof(int)*length_per_process);
    

    
}
 
  // Count the 0s in our local array.
  for (i = 0; i < length_per_process; i++)
    if (array[i] == 0)      count++;
  printf("Process %d's count is %d\n",rank,count);

  


// Allow the root processor to accumulate the counts.
  if (rank == ROOT_RANK){
    





    printf("The total count is %d\n",count);
  }
  else{
    



  }
  	

  free(array);
  return 0;
}

