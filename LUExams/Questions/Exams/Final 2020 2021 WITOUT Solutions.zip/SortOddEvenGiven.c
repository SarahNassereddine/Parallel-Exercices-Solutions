#include <stdio.h>
#include <stdlib.h>
#define  n 16
int main()
{
    int i;
	int a[n]= {15,11,5,4,7,6,14,13,9,2,3,0,1,8,12,10};  
    printf("\nArray Elements Before Sorting\n");
   
    for(i=0;i<n;i++)
    printf("\na[%d]=%d",i,a[i]);
      
    for(i=0;i<n;i++)
    {   
       //Sorting depending on the index Odd or Even
       
    }


//print the sorted array and the execution time 

}
