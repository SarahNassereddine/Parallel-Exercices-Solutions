double calculate_pi(double step) {
int i ;
double x, sum = 0.0;
#pragma omp parallel for reduction(+: sum) private(x)
for ( i=0;i<1000000;++i) {
x = (i−0.5) * step;
sum += 2.0 / (1.0 + x*x);
}
return step * sum;
}
