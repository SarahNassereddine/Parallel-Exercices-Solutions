#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <time.h>

#define THREAD_COUNT 10
#define OUTLET_COUNT 3

void* use_lamp(void* arg) {
    int thread_id = *(int*)arg;

    printf("[Thread %d] Wanting electrical current...\n", thread_id);

    printf("[Thread %d] Connected to power strip. Lamp is ON.\n", thread_id);
    sleep(1); // Lamp remains on for 1 second
    printf("[Thread %d] Disconnected. Lamp is OFF.\n", thread_id);

    free(arg);
    return NULL;
}

int main() {
    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    pthread_t threads[THREAD_COUNT];

    for (int i = 0; i < THREAD_COUNT; i++) {
        int* id = malloc(sizeof(int));
        *id = i + 1;

    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double time_taken = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;
    printf("Execution time: %.6f seconds\n", time_taken);

    return 0;
}
