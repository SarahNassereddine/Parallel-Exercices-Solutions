public class ThreadOrderStateQuestion {

   

    public static void main(String[] args) {
        long startTime = System.currentTimeMillis();
        
        Thread t1 = new Thread(new Worker("T1", 1));
        Thread t2 = new Thread(new Worker("T2", 2));
        Thread t3 = new Thread(new Worker("T3", 3));
        Thread t4 = new Thread(new Worker("T4", 4));
        Thread t5 = new Thread(new Worker("T5", 5));

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();

        // TODO: Wait for all threads to finish

        long endTime = System.currentTimeMillis();
        System.out.println("Execution time: " + (endTime - startTime) + " ms");
    }

    static class Worker implements Runnable {
        private final String name;
        private final int threadId;

        public Worker(String name, int threadId) {
            this.name = name;
            this.threadId = threadId;
        }

        @Override
        public void run() {
            // TODO: Implement the synchronization logic to enforce ordering
            System.out.println(name + " has executed.");
        }
    }
}
