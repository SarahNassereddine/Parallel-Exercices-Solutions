

public class SharedObjectExam {
    public StringBuilder sharedString;
    
    public SharedObjectExam() {
        sharedString = new StringBuilder(); 
    }

    public void appendString(String text) {
            sharedString.append(text);
    }

   class Task1 implements Runnable {
        public void run() {
            appendString("T1");
            System.out.println("END OF T1"); 
          } 
    }

    class Task2 implements Runnable {
        public void run() {
            appendString("T2");
            System.out.println("END OF T2");
          }
    }

    class Task3 implements Runnable {
        public void run() {
        appendString("T3");
        System.out.println("END OF T3");    
        }
    }

    class Task4 implements Runnable {
        public void run() {
                appendString("T4");
                System.out.println("END OF T4");   
        }
    }

    class Task5 implements Runnable {
        public void run() {
            appendString("T5");
            System.out.println("END OF T5"); 
        }
    }

    class EndTask implements Runnable {
        public void run() {

            appendString("END");
            System.out.println("THE END");
            System.out.println(sharedString.toString());
            
            }
        
    }

    public static void main(String[] args) throws InterruptedException {
        SharedObjectExam sharedObject = new SharedObjectExam();

        Thread t1 = new Thread(sharedObject.new Task1());
        Thread t2 = new Thread(sharedObject.new Task2());
        Thread t3 = new Thread(sharedObject.new Task3());
        Thread t4 = new Thread(sharedObject.new Task4());
        Thread t5 = new Thread(sharedObject.new Task5());
        Thread endThread = new Thread(sharedObject.new EndTask());

        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        endThread.start();
        if(endThread.isAlive())endThread.join();
        System.out.println("END OF MAIN as endThread is Alive : " + endThread.isAlive());
      
    }
}
