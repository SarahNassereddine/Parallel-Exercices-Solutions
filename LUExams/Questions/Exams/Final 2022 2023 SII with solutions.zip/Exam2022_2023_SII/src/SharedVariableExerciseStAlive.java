//Ali kansoun
//103577
import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;


public class SharedVariableExerciseStAlive {
    public static Lock lock=new ReentrantLock();
    public static int X;  // Shared variable

    public static Condition t11=lock.newCondition();
    public static Condition t22=lock.newCondition();
    public static Condition t33=lock.newCondition();
    public static Condition t44=lock.newCondition();

    public static Thread t1;
    public static Thread t2;
    public static Thread t3;
    public static Thread t4;



    public static void main(String[] args) {
        t1 = new Thread(new T1());
         t2 = new Thread(new T2());
         t3 = new Thread(new T3());
         t4 = new Thread(new T4());

   t1.start();
   t2.start();
   t3.start();
   t4.start();

    }

    static class T1 implements Runnable {
        @Override
        public void run() {
            lock.lock();
            try {

                Random rand = new Random();
                while (true) {
                    X = rand.nextInt(100) + 1;
                    System.out.println("T1 set X to " + X);
                    if (X % 5 == 0) {
                        System.out.println("T1 is done!");
                        if(t2.isAlive())
                            t22.signal();

                        else if(t3.isAlive())
                            t33.signal();

                        else if (t4.isAlive())
                            t44.signal();
                        return;

                    }

                    if(t2.isAlive()){
                        t22.signal();
                        t11.await();
                    }
                    else if(t3.isAlive()){
                        t33.signal();
                        t11.await();
                    }
                    else if (t4.isAlive()) {
                        t44.signal();
                        t11.await();
                    }
                }
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                lock.unlock();
            }
        }
    }

    static class T2 implements Runnable {
        @Override
        public void run() {
            lock.lock();
            try {
            Random rand = new Random();
            while (true) {
                X = rand.nextInt(100) + 1;
                System.out.println("T2 set X to " + X);
                if (X % 3 == 0) {
                    System.out.println("T2 is done!");
                    if(t1.isAlive())
                        t11.signal();

                    else if(t3.isAlive())
                        t33.signal();

                    else if (t4.isAlive())
                        t44.signal();
                    return;
                }
                if(t1.isAlive()){
                    t11.signal();
                    t22.await();
                }
                else if(t3.isAlive()){
                    t33.signal();
                    t22.await();
                }
                else if (t4.isAlive()) {
                    t44.signal();
                    t22.await();
                }
            }
        } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                lock.unlock();
            }
            }


    }
    static class T3 implements Runnable {
        @Override
        public void run() {
            lock.lock();
            try{
            Random rand = new Random();
            while (true) {
                X = rand.nextInt(100) + 1;
                System.out.println("T3 set X to " + X);
                if (X % 2 == 0) {
                    System.out.println("T3 is done!");

                    if(t1.isAlive())
                        t11.signal();
                    else if(t2.isAlive())
                        t22.signal();
                    else if (t4.isAlive())
                        t44.signal();

                    return;
                }
                if(t1.isAlive()){
                    t11.signal();
                    t33.await();
                }
                else if(t2.isAlive()){
                    t22.signal();
                    t33.await();
                }
                else if (t4.isAlive()) {
                    t44.signal();
                    t33.await();
                }
            }
        } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                lock.unlock();
            }
            }
    }

    static class T4 implements Runnable {
        @Override
        public void run() {
            lock.lock();
            try{
            Random rand = new Random();
            while (true) {
                X = rand.nextInt(100) + 1;
                System.out.println("T4 set X to " + X);
                if (X % 2 == 0) {
                    System.out.println("T4 is done!");
                    if(t1.isAlive())
                        t11.signal();

                    else if(t2.isAlive())
                        t22.signal();

                    else if (t3.isAlive())
                            t33.signal();
                    return;
                }
                if(t1.isAlive()){
                    t11.signal();
                    t44.await();
                }
                else if(t2.isAlive()){
                    t22.signal();
                    t44.await();
                }
                else if (t3.isAlive()) {
                    t33.signal();
                    t44.await();
                }

            }
        } catch (InterruptedException e) {
                throw new RuntimeException(e);
            } finally {
                lock.unlock();
            }
            }

    }

}