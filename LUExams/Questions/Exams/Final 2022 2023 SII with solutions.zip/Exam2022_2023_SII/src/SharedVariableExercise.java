
import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SharedVariableExercise {

    public static int X;  // Shared variable
    public static Lock lock = new ReentrantLock();
    public static Condition condition = lock.newCondition();
    static Thread t1 = new Thread(new T1());
    static Thread t2 = new Thread(new T2());
    static Thread t3 = new Thread(new T3());
    static Thread t4 = new Thread(new T4());

    public static void main(String[] args) {
        // Start threads
        t1.start();
        t2.start();
        t3.start();
        t4.start();
    }

    static class T1 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {
                try {
                    X = rand.nextInt(100) + 1;
                    lock.lock();
                    System.out.println("T1 set X to " + X);
                    if (X % 5 == 0) {
                        System.out.println("T1 is done!");
                        condition.signalAll();
                        return;
                    }
                    condition.signalAll();
                    System.out.println("T1 will await");
                    if (t2.isAlive() || t3.isAlive() || t4.isAlive()) {
                        condition.await();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    lock.unlock();
                }
            }
        }
    }

    static class T2 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();

            while (true) {
                try {
                    X = rand.nextInt(100) + 1;
                    lock.lock();
                    System.out.println("T2 set X to " + X);
                    if (X % 3 == 0) {
                        System.out.println("T2 is done!");
                        condition.signalAll();
                        return;
                        //In Java, the finally block is always executed, 
                        //regardless of whether a return statement is executed within the try block or not. 
                        //This ensures that the lock is properly released, 
                        //even if an exception occurred or if the thread exits prematurely due to the return statement.
                    }
                    condition.signalAll();
                    System.out.println("T2 will await");
                    if (t1.isAlive() || t3.isAlive() || t4.isAlive()) {
                        condition.await();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally { //Executed even there is a return in try
                    lock.unlock();
                }
            }
        }
    }

    static class T3 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();

            while (true) {
                try {
                    X = rand.nextInt(100) + 1;
                    lock.lock();
                    System.out.println("T3 set X to " + X);
                    if (X % 2 == 0) {
                        System.out.println("T3 is done!");
                        condition.signalAll();
                        return;
                    }
                    condition.signalAll();
                    System.out.println("T3 will await");
                    if (t1.isAlive() || t2.isAlive() || t4.isAlive()) {
                        condition.await();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    lock.unlock();
                }
            }
        }
    }

    static class T4 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();

            while (true) {
                try {
                    X = rand.nextInt(100) + 1;
                    lock.lock();
                    System.out.println("T4 set X to " + X);
                    if (X % 2 == 0) {
                        System.out.println("T4 is done!");
                        condition.signalAll();
                        return;
                    }
                    condition.signalAll();
                    System.out.println("T4 will await");
                    if (t1.isAlive() || t2.isAlive() || t3.isAlive()) {
                        condition.await();
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } finally {
                    lock.unlock();
                }
            }
        }
    }

}
