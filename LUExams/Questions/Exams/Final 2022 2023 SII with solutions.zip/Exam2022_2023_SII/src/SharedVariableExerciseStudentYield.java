// 99972_Nadim_Elhajjsleiman 

import java.util.Random;

// Pb that Each task can generate X and another Can Override it - Solve it by lock
public class SharedVariableExerciseStudentYield {

    public static int X;  // Shared variable

    public static void main(String[] args) {
        Thread t1 = new Thread(new T1());
        Thread t2 = new Thread(new T2());
        Thread t3 = new Thread(new T3());
        Thread t4 = new Thread(new T4());
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        while (t1.isAlive() || t2.isAlive() || t3.isAlive() || t4.isAlive());
    }

    static class T1 implements Runnable {

        @Override
        public void run() {

            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T1 set X to " + X);
                if (X % 5 == 0) {
                    System.out.println("T1 is done!");
                    return;
                }
                Thread.yield();

            }
        }
    }

    static class T2 implements Runnable {

        @Override
        public void run() {

            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T2 set X to " + X);
                if (X % 3 == 0) {
                    System.out.println("T2 is done!");
                    return;
                }
                Thread.yield();

            }
        }
    }

    static class T3 implements Runnable {

        @Override
        public void run() {

            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T3 set X to " + X);
                if (X % 2 == 0) {
                    System.out.println("T3 is done!");
                    return;
                }
                Thread.yield();

            }
        }
    }

    static class T4 implements Runnable {

        @Override
        public void run() {

            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T4 set X to " + X);
                if (X % 2 == 0) {
                    System.out.println("T4 is done!");
                    return;
                }
                Thread.yield();

            }
        }

    }

}
