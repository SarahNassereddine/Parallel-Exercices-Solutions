
// name = hussein hassan maatouk
// id = 107147
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
// Pb - lock ..Solve it

public class SharedVariableExerciseStudentYieldandLock {

    public static int X; // Shared variable
    public static ReentrantLock lock = new ReentrantLock();

    public static void main(String[] args) {
        Runnable t1 = new T1();
        Thread thread1 = new Thread(t1);
        Runnable t2 = new T2();
        Thread thread2 = new Thread(t2);
        Runnable t3 = new T3();
        Thread thread3 = new Thread(t3);
        Runnable t4 = new T4();
        Thread thread4 = new Thread(t4);
        thread1.start();
        thread3.start();
        thread2.start();
        thread4.start();
    }

    static class T1 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T1 set X to " + X);
                lock.lock();
                try {
                    if (X % 5 == 0) {
                        System.out.println("T1 is done!");
                        return;
                    }
                } finally {

                    lock.unlock();
                    Thread.yield();
                }

            }
        }
    }

    static class T2 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();

            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T2 set X to " + X);
                lock.lock();

                try {

                    if (X % 3 == 0) {
                        System.out.println("T2 is done!");
                        return;
                    }

                } finally {

                    lock.unlock();
                    Thread.yield();

                }

            }
        }
    }

    static class T3 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T3 set X to " + X);
                lock.lock();
                //
                try {

                    if (X % 2 == 0) {
                        System.out.println("T3 is done!");
                        return;
                    }

                } finally {
                    lock.unlock();
                    Thread.yield();

                }
            }
        }
    }

    static class T4 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {

                X = rand.nextInt(100) + 1;
                System.out.println("T4 set X to " + X);
                lock.lock();
                try {

                    if (X % 2 == 0) {
                        System.out.println("T4 is done!");
                        return;
                    }

                } finally {
                    lock.unlock();
                    Thread.yield();

                }
            }
        }

    }

}
