// ali awada 97860

import java.util.Random;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class SharedVariableExerciseStudent {

    static int TOTAL_NUMBER_OF_THREADS = 4;
    static int NumberOfFinishedThreads = 0;
    public static int X;  // Shared variable

    static Lock lock = new ReentrantLock();
    static Condition OneThreadShouldGo = lock.newCondition();

    public static void main(String[] args) throws InterruptedException {
        Thread T1 = new Thread(new T1());
        Thread T2 = new Thread(new T2());
        Thread T3 = new Thread(new T3());
        Thread T4 = new Thread(new T4());
        T1.start();
        T2.start();
        T3.start();
        T4.start();
    }

    static class T1 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {
                lock.lock();
                X = rand.nextInt(100) + 1;
                System.out.println("T1 set X to " + X);
                if (X % 5 == 0) {
                    System.out.println("T1 is done!");
                    NumberOfFinishedThreads++;
                    OneThreadShouldGo.signal();
                    lock.unlock();
                    return;
                }
                try {
                    // check if it is last thread => don't wait for signal
                    if (NumberOfFinishedThreads < TOTAL_NUMBER_OF_THREADS - 1) {
                        OneThreadShouldGo.signal();
                        OneThreadShouldGo.await();
                    }
                } catch (InterruptedException e) {
                }
                lock.unlock();
            }
        }
    }

    static class T2 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {
                lock.lock();
                X = rand.nextInt(100) + 1;
                System.out.println("T2 set X to " + X);
                try {
                    if (X % 3 == 0) {
                        System.out.println("T2 is done!");
                        NumberOfFinishedThreads++;
                        OneThreadShouldGo.signal();
                        lock.unlock();
                        return;
                    }
                    if (NumberOfFinishedThreads < TOTAL_NUMBER_OF_THREADS - 1) {
                        OneThreadShouldGo.signal();
                        OneThreadShouldGo.await();
                    }
                } catch (InterruptedException e) {
                }
                lock.unlock();
            }
        }
    }

    static class T3 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {
                lock.lock();
                X = rand.nextInt(100) + 1;
                System.out.println("T3 set X to " + X);

                try {
                    if (X % 2 == 0) {
                        System.out.println("T3 is done!");
                        NumberOfFinishedThreads++;
                        OneThreadShouldGo.signal();
                        lock.unlock();
                        return;
                    }
                    if (NumberOfFinishedThreads < TOTAL_NUMBER_OF_THREADS - 1) {
                        OneThreadShouldGo.signal();
                        OneThreadShouldGo.await();
                    }
                } catch (InterruptedException e) {
                }
                lock.unlock();
            }
        }
    }

    static class T4 implements Runnable {

        @Override
        public void run() {
            Random rand = new Random();
            while (true) {
                lock.lock();
                X = rand.nextInt(100) + 1;
                System.out.println("T4 set X to " + X);
                try {
                    if (X % 7 == 0) {
                        System.out.println("T4 is done!");
                        NumberOfFinishedThreads++;
                        OneThreadShouldGo.signal();
                        lock.unlock();
                        return;
                    }
                    if (NumberOfFinishedThreads < TOTAL_NUMBER_OF_THREADS - 1) {
                        OneThreadShouldGo.signal();
                        OneThreadShouldGo.await();
                    }
                } catch (InterruptedException e) {
                }
                lock.unlock();
            }
        }

    }
}
