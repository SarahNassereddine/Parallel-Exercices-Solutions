
import java.util.Random;


public class SharedVariableExerciseSt {
    public static int X;  // Shared variable
    
    public static void main(String[] args) {
 
    }

    static class T1 implements Runnable {
        @Override
        public void run() {
            Random rand = new Random();
         while (true) {
                    X = rand.nextInt(100) + 1;
                    System.out.println("T1 set X to " + X);
                    if (X % 5 == 0) {
                        System.out.println("T1 is done!");
                        return;
                    }
                }
        }
    }

    static class T2 implements Runnable {
        @Override
        public void run() {
            Random rand = new Random();
                while (true) {
                    X = rand.nextInt(100) + 1;
                    System.out.println("T2 set X to " + X);
                    if (X % 3 == 0) {
                        System.out.println("T2 is done!");
                           return;
                    }   
        }
    }
}
    static class T3 implements Runnable {
        @Override
        public void run() {
            Random rand = new Random();
                while (true) {
                    X = rand.nextInt(100) + 1;
                    System.out.println("T3 set X to " + X);
                    if (X % 2 == 0) {
                        System.out.println("T3 is done!");
                        return;
                    }
                }
        }
    }

    static class T4 implements Runnable {
        @Override
        public void run() {
            Random rand = new Random();
                while (true) {
                    
                    X = rand.nextInt(100) + 1;
                    System.out.println("T4 set X to " + X);
                    if (X % 2 == 0) {
                        System.out.println("T4 is done!");
                        return;
                    } 
        }
    }

}

}
