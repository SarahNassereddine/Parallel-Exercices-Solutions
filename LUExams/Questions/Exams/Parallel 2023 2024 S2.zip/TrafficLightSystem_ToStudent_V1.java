
public class TrafficLightSystem_ToStudent_V1 {

    private class GreenLight extends Thread {

        @Override
        public void run() {

            while (true) {

                System.out.println("GO");

            }
        }
    }

    private class YellowLight extends Thread {

        @Override
        public void run() {

            while (true) {

                System.out.println("Prepare to STOP");

            }

        }
    }

    private class RedLight extends Thread {

        @Override
        public void run() {

            while (true) {

                System.out.println("STOP");
            }

        }
    }

    public static void main(String[] args) {
        TrafficLightSystem_ToStudent_V1 system = new TrafficLightSystem_ToStudent_V1();

        Thread greenLightThread;
        greenLightThread = system.new GreenLight();
        Thread yellowLightThread = system.new YellowLight();
        Thread redLightThread = system.new RedLight();

        greenLightThread.start();
        yellowLightThread.start();
        redLightThread.start();
    }
}
